from setuptools import setup

setup(
    name="Barky",
    packages=["barkylib"],
)